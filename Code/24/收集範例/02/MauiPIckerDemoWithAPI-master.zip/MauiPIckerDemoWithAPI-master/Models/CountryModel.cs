﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DropDownDemoWithAPI.Models
{
    public class CountryModel
    {
       public string Country_Name { get; set; }
        public string Country_Short_Name { get; set; }

    }
}
