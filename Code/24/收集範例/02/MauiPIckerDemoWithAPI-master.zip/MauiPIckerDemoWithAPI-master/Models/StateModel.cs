﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DropDownDemoWithAPI.Models
{
    public class StateModel
    {
        public string State_Name { get; set; }
    }
}
