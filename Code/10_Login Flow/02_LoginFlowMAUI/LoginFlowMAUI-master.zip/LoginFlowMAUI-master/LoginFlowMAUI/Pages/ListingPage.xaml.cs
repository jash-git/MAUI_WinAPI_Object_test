namespace LoginFlowMAUI.Pages;

public partial class ListingPage : ContentPage
{
	public ListingPage()
	{
		InitializeComponent();
	}
}