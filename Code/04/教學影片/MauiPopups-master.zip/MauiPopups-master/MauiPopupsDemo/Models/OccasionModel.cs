﻿namespace MauiPopupsDemo.Models
{
    public class OccasionModel
    {
        public DateTime Date { get; set; }

        public string Occasion { get; set; }

        public string Notes { get; set; }

        public string Image { get; set; }
    }
}
