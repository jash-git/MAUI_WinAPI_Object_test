# Maui Popups

Popups are very common either it could be a Web App, Windows App or Mobile App. <br/>
We can display a piece of information, or we can collect user inputs using Popups. <br/>
Today, we're going to implement Popups in .Net MAUI using .Net MAUI Community Toolkit. <br/>

I’m assuming that you have a basic understanding of .NET MAUI.

<a href="https://youtu.be/MHLfbEILlNU">Watch this on Youtube</a> <br/>

<a href="https://www.youtube.com/playlist?list=PLo-ZNwEHZHqZGQzZfkjqloxk8p-A68E0s">Complete MAUI Playlist</a></br>

Follow us on <br/>
<a href="https://twitter.com/Skynetechs">twitter</a> <br/>
<a href="https://www.facebook.com/Skynetfor.net">facebook</a>

<br/>
<a href="https://github.com/Skynet-Demos">All Skynet-Demo Git Repos</a> <br/>
